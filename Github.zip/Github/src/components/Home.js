const Home = ({ children }) => {
  return (
    <div className="card-started" id="home-card">
      {children}
    </div>
  );
};
export default Home;
