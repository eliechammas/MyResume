import dynamic from "next/dynamic";

const Index = () => {
  return (
    <Layout>
    </Layout>
  );
};
export default Index;
